<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => env('TEST_USER_NAME', 'Test User'),
            'email' => env('TEST_USER_EMAIL', 'test@example.com'),
            'email_verified_at' => now(),
            'password' => Hash::make(env('TEST_USER_PASSWORD', 'password')),
            'is_admin' => false,
        ]);

        User::create([
            'name' => env('ADMIN_USER_NAME', 'Admin User'),
            'email' => env('ADMIN_EMAIL', 'admin@example.com'),
            'email_verified_at' => now(),
            'password' => Hash::make(env('ADMIN_PASSWORD', 'password')),
            'is_admin' => true,
        ]);
    }
}
