<?php

use Illuminate\Support\Facades\Schedule;

Schedule::command('migrate:fresh', ['--force' => true])->everyThirtyMinutes();
Schedule::command('db:seed', ['--force' => true])->everyThirtyMinutes();
