<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\NoteController;
use Illuminate\Support\Facades\Route;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;

// Public routes
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/auth/login', [AuthController::class, 'login'])->name('login.submit');
Route::get('/admin/login', [AuthController::class, 'showAdminLogin'])->name('admin.login');
Route::post('/admin/auth/login', [AuthController::class, 'adminLogin'])->name('admin.login.submit');
Route::get('/logout', function () {throw new MethodNotAllowedHttpException(['POST'], 'The GET method is not supported for route logout. Supported methods: POST.');});
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register']);

// Protected routes
Route::middleware('auth')->group(function () {
    Route::get('/', fn () => redirect()->route('notes.index'));
    Route::get('/dashboard', fn () => redirect()->route('notes.index'));

    // Notes
    Route::get('/notes', [NoteController::class, 'index'])->name('notes.index');
    Route::post('/notes', [NoteController::class, 'store'])->name('notes.store');
    Route::get('/notes/{note}', [NoteController::class, 'show'])->name('notes.show');
    Route::delete('/notes/{note}', [NoteController::class, 'destroy'])->name('notes.destroy');
    Route::post('/notes/{note}/attachments', [NoteController::class, 'uploadAttachment'])->name('notes.attachments.store');
    Route::delete('/notes/{note}/attachments/{attachment}', [NoteController::class, 'deleteAttachment'])->name('notes.attachments.destroy');
    Route::post('/notes/{note}/report', [NoteController::class, 'report'])->name('notes.report');

    // Admin routes
    Route::middleware('admin')->prefix('admin')->group(function () {
        Route::get('/notes', [AdminController::class, 'allNotes'])->name('admin.notes');
        Route::get('/notes/{note}', [AdminController::class, 'showNote'])->name('admin.notes.show')->middleware('csp');
        Route::get('/fetch', [AdminController::class, 'showFetchForm'])->name('admin.fetch');
        Route::post('/fetch', [AdminController::class, 'fetchUrl']);
    });
});
