<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SendNoteForReview implements ShouldQueue
{
    use Dispatchable, Queueable;

    public int $tries = 1;

    public int $timeout = 120;

    public function __construct(
        public string $botUrl,
        public string $targetUrl,
    ) {}

    public function handle(): void
    {
        $botTimeout = (int) config('services.bot.timeout', 90);
        $botConnectTimeout = (int) config('services.bot.connect_timeout', 5);

        $response = Http::asForm()
            ->connectTimeout($botConnectTimeout)
            ->timeout($botTimeout)
            ->post(rtrim($this->botUrl, '/') . '/visit', [
                'url' => $this->targetUrl,
            ]);

        if (! $response->successful()) {
            throw new \RuntimeException('Admin bot returned a non-success response.');
        }
    }

    public function failed(?\Throwable $exception): void
    {
        Log::warning('Admin review job failed.', [
            'bot_url' => $this->botUrl,
            'target_url' => $this->targetUrl,
            'error' => $exception?->getMessage(),
        ]);
    }
}
