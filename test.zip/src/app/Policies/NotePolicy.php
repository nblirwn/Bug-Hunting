<?php

namespace App\Policies;

use App\Models\Note;
use App\Models\User;

class NotePolicy
{
    public function view(User $user, Note $note): bool
    {
        return $user->id === $note->user_id || $user->is_admin;
    }

    public function update(User $user, Note $note): bool
    {
        return $user->id === $note->user_id || $user->is_admin;
    }

    public function delete(User $user, Note $note): bool
    {
        return $user->id === $note->user_id || $user->is_admin;
    }
}
