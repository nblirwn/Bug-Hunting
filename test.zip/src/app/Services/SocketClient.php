<?php

namespace App\Services;

class SocketClient
{
    public function probe(string $host, int $port, string $path, int $timeout = 10): array
    {
        $fp = @fsockopen($host, $port, $errno, $errstr, $timeout);

        if (! $fp) {
            throw new \RuntimeException("Connection refused: {$host}:{$port}");
        }

        stream_set_timeout($fp, $timeout);

        $head = "GET {$path} HTTP/1.0\r\n";
        $head .= "Host: {$host}\r\n";
        $head .= "Connection: close\r\n\r\n";

        fwrite($fp, $head);

        $raw = '';
        while (! feof($fp)) {
            $chunk = fread($fp, 8192);
            if ($chunk === false || $chunk === '') {
                break;
            }
            $raw .= $chunk;
        }
        fclose($fp);

        return $this->parseResponse($raw);
    }

    private function parseResponse(string $raw): array
    {
        $split = strpos($raw, "\r\n\r\n");

        if ($split === false) {
            return ['status' => 0, 'body' => $raw, 'content_type' => 'text/html'];
        }

        $headers = substr($raw, 0, $split);
        $body = substr($raw, $split + 4);

        $status = 0;
        if (preg_match('/^HTTP\/\d\.\d\s+(\d+)/', $headers, $m)) {
            $status = (int) $m[1];
        }

        $contentType = 'text/html';
        if (preg_match('/Content-Type:\s*([^\r\n]+)/i', $headers, $m)) {
            $contentType = trim($m[1]);
        }

        return [
            'status' => $status,
            'body' => $body,
            'content_type' => $contentType,
        ];
    }
}
