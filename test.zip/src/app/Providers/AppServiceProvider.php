<?php

namespace App\Providers;

use App\Models\Attachment;
use App\Models\Note;
use App\Policies\AttachmentPolicy;
use App\Policies\NotePolicy;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Gate::policy(Note::class, NotePolicy::class);
        Gate::policy(Attachment::class, AttachmentPolicy::class);

        Blade::directive('cspnonce', function () {
            return "<?php echo 'nonce=\"' . request()->attributes->get('csp_nonce', '') . '\"'; ?>";
        });
    }
}
