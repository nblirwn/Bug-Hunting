<?php

namespace App\Http\Controllers;

use App\Models\Note;
use App\Models\User;
use App\Services\SocketClient;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class AdminController extends Controller implements HasMiddleware
{
    public function __construct(
        private SocketClient $socket,
    ) {}

    public static function middleware(): array
    {
        return [
            new Middleware('admin'),
        ];
    }

    public function allNotes()
    {
        $notes = Note::with('user')->orderBy('created_at', 'desc')->get();

        return view('admin.notes', compact('notes'));
    }

    public function showNote(Note $note)
    {
        $note->load('user', 'attachments');

        return view('admin.notes-show', compact('note'));
    }

    public function allUsers()
    {
        $users = User::with('notes')->get();

        return view('admin.users', compact('users'));
    }

    public function showFetchForm()
    {
        return view('admin.fetch');
    }

    public function fetchUrl(Request $request)
    {
        $validated = $request->validate([
            'url' => 'required|string|max:2048',
        ]);

        $parsed = parse_url($validated['url']);
        $scheme = $parsed['scheme'] ?? null;
        $host = $parsed['host'] ?? null;

        if (! $this->isTrusted($scheme, $host)) {
            return back()->withErrors(['url' => 'Only its.ac.id URLs are allowed.'])->withInput();
        }

        try {
            $port = $parsed['port'] ?? (($scheme ?? 'http') === 'https' ? 443 : 80);
            $path = ($parsed['path'] ?? '/').(isset($parsed['query']) ? '?'.$parsed['query'] : '');

            preg_match('#^https?://([^/:?\#]+)#', $validated['url'], $rawHostMatch);
            $rawHost = $rawHostMatch[1] ?? $host;

            $result = $this->socket->probe($rawHost, $port, $path);

            $contentType = 'html';
            if (! str_contains($result['content_type'], 'text/html') && ! str_contains($result['content_type'], 'text/plain')) {
                $contentType = 'raw';
            }

            return view('admin.fetch', [
                'content' => $result['body'],
                'statusCode' => $result['status'],
                'contentType' => $contentType,
                'fetchedUrl' => $validated['url'],
            ]);
        } catch (\RuntimeException $e) {
            return back()->withErrors(['url' => $e->getMessage()])->withInput();
        } catch (\Exception $e) {
            return back()->withErrors(['url' => 'An error occurred while fetching the URL.'])->withInput();
        }
    }

    private function isTrusted(?string $protocol, ?string $host): bool
    {
        if (! $host || ! $protocol) {
            return false;
        }

        $protocol = strtolower($protocol);
        $host = strtolower($host);

        if (($protocol === 'https' || $protocol === 'http') && str_ends_with($host, 'its.ac.id')) {
            return true;
        }

        return false;
    }
}
