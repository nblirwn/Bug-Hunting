<?php

namespace App\Http\Controllers;

use App\Jobs\SendNoteForReview;
use App\Models\Attachment;
use App\Models\Note;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;

class NoteController extends Controller
{
    public function index(Request $request)
    {
        if (Auth::user()->is_admin && $request->has('all')) {
            $notes = Note::with('user')->orderBy('created_at', 'desc')->get();
        } else {
            $notes = Auth::user()->notes()->orderBy('created_at', 'desc')->get();
        }

        return view('notes.index', compact('notes'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'nullable|string',
        ]);

        Auth::user()->notes()->create([
            'title' => $validated['title'],
            'content' => $validated['content'] ?? null,
        ]);

        return redirect()->back();
    }

    public function show(Note $note)
    {
        $this->authorize('view', $note);
        $note->load('attachments');

        $alreadyUploaded = Attachment::where('note_id', $note->id)->where('user_id', Auth::id())->exists();

        return view('notes.show', compact('note', 'alreadyUploaded'));
    }

    public function destroy(Note $note)
    {
        $this->authorize('delete', $note);
        $note->delete();

        return redirect()->route('notes.index');
    }

    public function uploadAttachment(Request $request, Note $note)
    {
        $this->authorize('view', $note);

        if (Attachment::where('note_id', $note->id)->where('user_id', Auth::id())->exists()) {
            return back()->withErrors(['file' => 'You have already uploaded an attachment to this note.']);
        }

        $validated = $request->validate([
            'file' => 'required|file|max:10240|mimes:jpg,jpeg,png,gif,pdf,doc,docx,txt,csv,xlsx',
        ]);

        $file = $validated['file'];
        $path = $file->store('attachments', 'public');

        Attachment::create([
            'note_id' => $note->id,
            'user_id' => Auth::id(),
            'filename' => $file->getClientOriginalName(),
            'path' => $path,
            'mime_type' => $file->getMimeType(),
            'size' => $file->getSize(),
            'expires_at' => now()->addMinutes(10),
        ]);

        return redirect()->route('notes.show', $note);
    }

    public function report(Note $note)
    {
        $this->authorize('view', $note);

        $userId = (string) Auth::id();
        $rateLimitKey = 'note-review:'.$userId;

        if (RateLimiter::tooManyAttempts($rateLimitKey, 1)) {
            $seconds = RateLimiter::availableIn($rateLimitKey);

            return back()->withErrors([
                'report' => "You can only send one review request per minute. Try again in {$seconds} seconds.",
            ]);
        }

        RateLimiter::hit($rateLimitKey, 60);

        $botUrl = config('services.bot.url');
        $noteUrl = route('admin.notes.show', $note, absolute: false);
        $appUrl = config('app.url');

        $fullUrl = rtrim($appUrl, '/') . $noteUrl;

        SendNoteForReview::dispatch($botUrl, $fullUrl);

        return back()->with('reported', 'Admin review has been queued.');
    }

    public function deleteAttachment(Note $note, Attachment $attachment)
    {
        $this->authorize('delete', $attachment);

        if ($attachment->note_id !== $note->id) {
            abort(403);
        }

        $attachment->delete();

        return redirect()->route('notes.show', $note);
    }
}
