<?php

namespace App\Http\Controllers;

use App\Models\Attachment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class AttachmentController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'file' => 'required|file|max:10240',
            'task_id' => 'nullable|exists:tasks,id',
            'note_id' => 'nullable|exists:notes,id',
        ]);

        $file = $request->file('file');
        $path = $file->store('attachments', 'public');

        Auth::user()->attachments()->create([
            'task_id' => $validated['task_id'] ?? null,
            'note_id' => $validated['note_id'] ?? null,
            'filename' => $file->getClientOriginalName(),
            'path' => $path,
            'mime_type' => $file->getMimeType(),
            'size' => $file->getSize(),
        ]);

        return redirect()->back();
    }

    public function download(Attachment $attachment)
    {
        $this->authorize('view', $attachment);
        return Storage::disk('public')->download($attachment->path, $attachment->filename);
    }

    public function destroy(Attachment $attachment)
    {
        $this->authorize('delete', $attachment);
        Storage::disk('public')->delete($attachment->path);
        $attachment->delete();
        return redirect()->back();
    }
}
