<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CspMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $nonce = base64_encode(random_bytes(16));
        $request->attributes->set('csp_nonce', $nonce);

        $response = $next($request);

        $response->headers->set('Content-Security-Policy',
            "default-src 'self'; ".
            "script-src 'self' https://cdn.tailwindcss.com 'nonce-{$nonce}'; ".
            "style-src 'self' https://cdn.tailwindcss.com https://fonts.googleapis.com 'unsafe-inline'; ".
            "img-src 'self'; ".
            "font-src 'self' https://fonts.gstatic.com; ".
            "connect-src 'self'; ".
            "frame-src 'none'; ".
            "object-src 'none'; ".
            "base-uri 'self'; ".
            "form-action 'self'"
        );

        return $response;
    }
}
