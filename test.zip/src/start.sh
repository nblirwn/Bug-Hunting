#!/bin/sh
set -e

echo "Waiting for database..."
max_attempts=30
attempt=0
until php -r '
$host = getenv("DB_HOST") ?: "db";
$port = getenv("DB_PORT") ?: "3306";
$db = getenv("DB_DATABASE") ?: "laravel";
$user = getenv("DB_USERNAME") ?: "laravel";
$pass = getenv("DB_PASSWORD") ?: "secret";
try {
    new PDO("mysql:host=$host;port=$port;dbname=$db", $user, $pass);
    exit(0);
} catch (Exception $e) {
    exit(1);
}
' >/dev/null 2>&1; do
    attempt=$((attempt + 1))
    if [ "$attempt" -ge "$max_attempts" ]; then
        echo "Database not ready after $max_attempts attempts. Exiting."
        exit 1
    fi
    echo "Database not ready, retrying in 2s... (attempt $attempt/$max_attempts)"
    sleep 2
done
echo "Database ready!"

APP_ROLE="${APP_ROLE:-app}"

if [ "$APP_ROLE" = "worker" ] || [ "$APP_ROLE" = "scheduler" ]; then
    exec php artisan queue:work --sleep=1 --tries=1 --timeout="${QUEUE_WORKER_TIMEOUT:-120}"
fi

php artisan migrate:fresh --force
php artisan db:seed --force
php artisan storage:link --force >/dev/null 2>&1 || true
php artisan config:cache
php artisan view:cache
php artisan route:cache

echo "*/60 * * * * php /var/www/html/artisan migrate:fresh --seed --force >> /dev/null 2>&1" | crontab -
crond -f &

exec php-fpm -F
