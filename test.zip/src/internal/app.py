from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os

FLAG = os.environ.get("FLAG")


class MetadataHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({"flag": FLAG}).encode())

    def log_message(self, format, *args):
        print(f"[metadata] {args[0]}")


if __name__ == "__main__":
    server = HTTPServer(("0.0.0.0", 1337), MetadataHandler)
    server.serve_forever()
