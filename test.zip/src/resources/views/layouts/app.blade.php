<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes App</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="{{ asset('css/sakura.min.css') }}" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif;
        }
    </style>
</head>
<body class="bg-[#121212] text-zinc-50 min-h-screen antialiased selection:bg-zinc-800 selection:text-zinc-50 flex flex-col">
    @auth
    <nav class="border-b border-zinc-800 bg-[#121212]/80 backdrop-blur-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 h-14 flex justify-between items-center">
            <div class="flex gap-6 items-center">
                <a href="{{ route('notes.index') }}" class="font-semibold text-lg tracking-tight text-zinc-50">Notes App</a>
                <div class="flex gap-4 items-center text-sm font-medium text-zinc-400">
                    <a href="{{ route('notes.index') }}" class="hover:text-zinc-50 transition-colors">Notes</a>
                    @if(auth()->user()->is_admin)
                    <a href="{{ route('admin.notes') }}" class="hover:text-zinc-50 transition-colors">Admin Notes</a>
                    <a href="{{ route('admin.fetch') }}" class="hover:text-zinc-50 transition-colors">URL Fetch</a>
                    @endif
                </div>
            </div>
            <form action="{{ route('logout') }}" method="POST" class="m-0">
                @csrf
                <button type="submit" class="text-sm font-medium text-zinc-400 hover:text-zinc-50 transition-colors">Logout</button>
            </form>
        </div>
    </nav>
    @endauth

    <main class="max-w-7xl w-full mx-auto px-4 py-8 flex-1 flex flex-col @guest justify-center @endguest relative z-10">
        @yield('content')
    </main>
    @stack('scripts')
    <script src="{{ asset('js/sakura.min.js') }}" @cspnonce></script>
    <script @cspnonce>
        document.addEventListener("DOMContentLoaded", function() {
            new Sakura('body', {
                delay: 200,
            });
        });
    </script>
</body>
</html>