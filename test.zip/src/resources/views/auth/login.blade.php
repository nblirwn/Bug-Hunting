@extends('layouts.app')

@section('content')
<div class="max-w-md w-full mx-auto relative z-10">
    <div class="bg-[#121212] border border-zinc-800 rounded-xl shadow-sm p-8">
        <div class="mb-8 text-center">
            <h1 class="text-2xl font-semibold tracking-tight text-zinc-50">Welcome back</h1>
            <p class="text-sm text-zinc-400 mt-2">Enter your email to sign in to your account</p>
        </div>

        @if($errors->any())
        <div class="bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-3 rounded-md mb-6 text-sm">
            @foreach($errors->all() as $error)
            <p>{{ $error }}</p>
            @endforeach
        </div>
        @endif

        <form action="{{ route('login.submit') }}" method="POST" class="space-y-4">
            @csrf
            <div class="space-y-2">
                <label class="text-sm font-medium leading-none text-zinc-200">Email</label>
                <input type="email" name="email" required class="flex h-10 w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm text-zinc-50 placeholder:text-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-300 transition-colors" placeholder="m@example.com">
            </div>
            <div class="space-y-2">
                <label class="text-sm font-medium leading-none text-zinc-200">Password</label>
                <input type="password" name="password" required class="flex h-10 w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm text-zinc-50 placeholder:text-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-300 transition-colors" placeholder="••••••••">
            </div>
            <button type="submit" class="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-zinc-300 bg-zinc-50 text-zinc-900 hover:bg-zinc-200 h-10 px-4 py-2 w-full mt-2">
                Sign In
            </button>
            <div class="text-center mt-6">
                <p class="text-sm text-zinc-400">Don't have an account? <a href="{{ route('register') }}" class="text-zinc-50 hover:underline underline-offset-4 font-medium">Register</a></p>
            </div>
        </form>
    </div>
</div>

@endsection