@extends('layouts.app')

@section('content')
<div class="w-full mx-auto">
    <div class="mb-8">
        <h1 class="text-3xl font-semibold tracking-tight text-zinc-50">URL Fetch</h1>
        <p class="text-sm text-zinc-400 mt-1">Fetch and inspect content from its.ac.id only.</p>
    </div>

    <div class="bg-[#121212] border border-zinc-800 rounded-xl p-6 shadow-sm mb-8">
        <form action="{{ route('admin.fetch') }}" method="POST">
            @csrf
            <div class="flex flex-col sm:flex-row gap-4">
                <input type="url" name="url" value="{{ old('url') }}" placeholder="https://its.ac.id/..." required
                    class="flex h-10 w-full flex-1 rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm text-zinc-50 placeholder:text-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-300 transition-colors @error('url') border-red-500 @enderror">
                <button type="submit" class="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-zinc-300 bg-zinc-50 text-zinc-900 hover:bg-zinc-200 h-10 px-8 w-full sm:w-auto shrink-0">
                    Fetch
                </button>
            </div>
            @error('url')
            <p class="text-red-400 text-sm mt-2 font-medium">{{ $message }}</p>
            @enderror
        </form>
    </div>

    @isset($content)
    <div class="bg-[#121212] border border-zinc-800 rounded-xl shadow-sm overflow-hidden">
        <div class="p-6 border-b border-zinc-800 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 bg-zinc-900/30">
            <h2 class="text-lg font-semibold text-zinc-50">Result</h2>
            <div class="flex items-center gap-3 text-sm">
                <span class="text-zinc-400">URL: <a href="{{ $fetchedUrl }}" target="_blank" class="text-zinc-50 hover:underline font-medium truncate max-w-[200px] sm:max-w-xs inline-block align-bottom">{{ $fetchedUrl }}</a></span>
                <span class="inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-semibold font-mono {{ $statusCode < 400 ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20' }}">
                    HTTP {{ $statusCode }}
                </span>
            </div>
        </div>

        <div class="p-6">
            <pre class="border border-zinc-800 rounded-md p-4 bg-zinc-900 overflow-auto max-h-[600px] text-sm text-zinc-300 whitespace-pre-wrap font-mono">{{ $content }}</pre>
        </div>
    </div>
    @endisset
</div>
@endsection