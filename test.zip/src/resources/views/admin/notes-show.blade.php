@extends('layouts.app')

@section('content')
<div class="w-full mx-auto space-y-6">
    <div class="bg-[#121212] border border-zinc-800 rounded-xl p-6 md:p-8 shadow-sm relative">
        <div class="absolute top-6 right-6">
            <span class="inline-flex items-center rounded-full border border-red-500/20 bg-red-500/10 px-2.5 py-0.5 text-xs font-semibold text-red-500">
                Admin View
            </span>
        </div>
        
        <h1 class="text-2xl md:text-3xl font-semibold tracking-tight text-zinc-50 pr-24 mb-6">{{ $note->title }}</h1>
        
        <div class="flex items-center gap-3 mb-8 bg-zinc-900/50 p-4 rounded-lg border border-zinc-800 inline-flex">
            <div class="h-10 w-10 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-sm font-semibold text-zinc-300 shrink-0">
                {{ substr($note->user->name ?? '?', 0, 1) }}
            </div>
            <div class="text-sm">
                <p class="font-medium text-zinc-200">{{ $note->user->name ?? 'Unknown User' }}</p>
                <p class="text-zinc-500">{{ $note->user->email ?? 'No email provided' }}</p>
            </div>
        </div>

        @if($note->content)
        <div class="mb-8 prose prose-invert max-w-none text-zinc-300">
            <p class="whitespace-pre-wrap leading-relaxed">{!! $note->content !!}</p>
        </div>
        @endif

        <div class="flex flex-wrap gap-x-4 gap-y-2 text-xs font-medium text-zinc-500 border-t border-zinc-800 pt-4 mt-6">
            <span>Created: {{ $note->created_at->format('M d, Y H:i') }}</span>
            @if($note->updated_at != $note->created_at)
            <span>&bull;</span>
            <span>Updated: {{ $note->updated_at->format('M d, Y H:i') }}</span>
            @endif
        </div>
    </div>

    <div class="pt-4">
        <a href="{{ route('admin.notes') }}" class="inline-flex items-center text-sm font-medium text-zinc-400 hover:text-zinc-50 transition-colors">
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back to All Notes
        </a>
    </div>
</div>
@endsection