@extends('layouts.app')

@section('content')
<div class="w-full mx-auto">
    <div class="mb-8 flex items-center justify-between">
        <div>
            <h1 class="text-3xl font-semibold tracking-tight text-zinc-50">All Notes</h1>
            <p class="text-sm text-zinc-400 mt-1">Administrator view of all user notes.</p>
        </div>
    </div>

    <div class="bg-[#121212] border border-zinc-800 rounded-xl overflow-hidden shadow-sm">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left">
                <thead class="text-xs text-zinc-400 uppercase bg-zinc-900/50 border-b border-zinc-800 font-semibold">
                    <tr>
                        <th scope="col" class="px-6 py-4">Title</th>
                        <th scope="col" class="px-6 py-4">User</th>
                        <th scope="col" class="px-6 py-4">Created</th>
                        <th scope="col" class="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-zinc-800">
                    @forelse($notes as $note)
                    <tr class="hover:bg-zinc-800/50 transition-colors">
                        <td class="px-6 py-4 font-medium text-zinc-50">{{ $note->title }}</td>
                        <td class="px-6 py-4 text-zinc-300">
                            <div class="flex items-center gap-2">
                                <div class="h-6 w-6 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-xs font-medium text-zinc-300 shrink-0">
                                    {{ substr($note->user->name ?? '?', 0, 1) }}
                                </div>
                                <span>{{ $note->user->name ?? 'N/A' }}</span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-zinc-400">{{ $note->created_at->format('M d, Y H:i') }}</td>
                        <td class="px-6 py-4 text-right">
                            <a href="{{ route('admin.notes.show', $note) }}" class="inline-flex items-center justify-center rounded-md text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-zinc-300 bg-zinc-800 text-zinc-50 hover:bg-zinc-700 h-8 px-3">
                                View
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="px-6 py-12 text-center text-zinc-500 bg-[#121212]">
                            No notes found in the system.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection