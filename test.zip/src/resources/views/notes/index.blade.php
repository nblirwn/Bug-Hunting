@extends('layouts.app')

@section('content')
<div class="flex justify-between items-center mb-8">
    <h1 class="text-3xl font-semibold tracking-tight text-zinc-50">My Notes</h1>
    <button id="openNoteModal" class="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-zinc-300 bg-zinc-50 text-zinc-900 hover:bg-zinc-200 h-10 px-4 py-2">
        New Note
    </button>
</div>

<!-- New Note Modal -->
<div id="newNoteModal" class="hidden fixed inset-0 bg-[#121212]/80 backdrop-blur-sm flex items-center justify-center z-50">
    <div class="bg-[#121212] border border-zinc-800 rounded-xl p-6 w-full max-w-md shadow-lg">
        <div class="mb-6">
            <h2 class="text-xl font-semibold tracking-tight text-zinc-50">Create New Note</h2>
            <p class="text-sm text-zinc-400 mt-1">Add a new note to your collection.</p>
        </div>
        <form action="{{ route('notes.store') }}" method="POST" class="space-y-4">
            @csrf
            <div class="space-y-2">
                <label class="text-sm font-medium leading-none text-zinc-200">Title</label>
                <input type="text" name="title" required class="flex h-10 w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm text-zinc-50 placeholder:text-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-300 transition-colors">
            </div>
            <div class="space-y-2">
                <label class="text-sm font-medium leading-none text-zinc-200">Content</label>
                <textarea name="content" rows="4" class="flex min-h-[80px] w-full rounded-md border border-zinc-800 bg-transparent px-3 py-2 text-sm text-zinc-50 placeholder:text-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-300 transition-colors"></textarea>
            </div>
            <div class="flex justify-end gap-3 pt-2">
                <button type="button" id="closeNoteModal" class="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-zinc-300 border border-zinc-800 bg-transparent hover:bg-zinc-800 text-zinc-50 h-10 px-4 py-2">Cancel</button>
                <button type="submit" class="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-zinc-300 bg-zinc-50 text-zinc-900 hover:bg-zinc-200 h-10 px-4 py-2">Create</button>
            </div>
        </form>
    </div>
</div>

<!-- Notes Grid -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
    @forelse($notes as $note)
    <a href="{{ route('notes.show', $note) }}" class="rounded-xl border border-zinc-800 bg-[#121212] p-5 shadow-sm hover:border-zinc-600 transition-all group flex flex-col">
        <div class="flex justify-between items-start mb-2">
            <h3 class="font-semibold text-lg text-zinc-50 group-hover:text-zinc-300 transition-colors line-clamp-1">{{ $note->title }}</h3>
            @if(auth()->user()->is_admin && isset($note->user))
            <span class="inline-flex items-center rounded-full border border-zinc-800 px-2.5 py-0.5 text-xs font-semibold text-zinc-300">{{ $note->user->name }}</span>
            @endif
        </div>
        @if($note->content)
        <p class="text-zinc-400 text-sm leading-relaxed line-clamp-3 mb-4 flex-1">{{ $note->content }}</p>
        @else
        <div class="flex-1 mb-4"></div>
        @endif
        <div class="flex items-center text-zinc-500 text-xs font-medium mt-auto">
            <svg class="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
            {{ $note->created_at->format('M d, Y') }}
        </div>
    </a>
    @empty
    <div class="col-span-full py-16 text-center border border-dashed border-zinc-800 rounded-xl">
        <p class="text-zinc-400 text-sm">No notes yet. Create your first note!</p>
    </div>
    @endforelse
</div>
@endsection

@push('scripts')
<script @cspnonce>
document.getElementById('openNoteModal').addEventListener('click', function () {
    document.getElementById('newNoteModal').classList.remove('hidden');
});
document.getElementById('closeNoteModal').addEventListener('click', function () {
    document.getElementById('newNoteModal').classList.add('hidden');
});
</script>
@endpush