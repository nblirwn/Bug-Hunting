@extends('layouts.app')

@section('content')
<div class="w-full mx-auto space-y-6">
    <div class="bg-[#121212] border border-zinc-800 rounded-xl p-6 md:p-8 shadow-sm">
        <div class="flex flex-col sm:flex-row sm:justify-between sm:items-start mb-6 gap-4">
            <h1 class="text-2xl md:text-3xl font-semibold tracking-tight text-zinc-50">{{ $note->title }}</h1>
            <form id="deleteNoteForm" action="{{ route('notes.destroy', $note) }}" method="POST" class="shrink-0">
                @csrf @method('DELETE')
                <button type="submit" class="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-red-500 bg-red-500/10 text-red-500 hover:bg-red-500/20 border border-red-500/20 h-9 px-4 py-2">
                    Delete Note
                </button>
            </form>
        </div>

        @if($note->content)
        <div class="mb-8 prose prose-invert max-w-none text-zinc-300">
            <p class="whitespace-pre-wrap leading-relaxed">{{ $note->content }}</p>
        </div>
        @endif

        <div class="flex flex-wrap gap-x-4 gap-y-2 text-xs font-medium text-zinc-500 pt-4 border-t border-zinc-800">
            <span>Created: {{ $note->created_at->format('M d, Y H:i') }}</span>
            @if($note->updated_at != $note->created_at)
            <span>&bull;</span>
            <span>Updated: {{ $note->updated_at->format('M d, Y H:i') }}</span>
            @endif
        </div>
    </div>

    <div class="bg-[#121212] border border-zinc-800 rounded-xl p-6 md:p-8 shadow-sm">
        <h2 class="text-xl font-semibold tracking-tight mb-4 text-zinc-50">Attachments</h2>
        @if($alreadyUploaded)
        <div class="border border-zinc-800 bg-zinc-900/50 p-4 rounded-lg">
            <p class="text-zinc-400 text-sm">You have already uploaded an attachment to this note.</p>
        </div>
        @else
        <form action="{{ route('notes.attachments.store', $note) }}" method="POST" enctype="multipart/form-data" class="border border-zinc-800 bg-zinc-900/50 p-4 rounded-lg">
            @csrf
            <div class="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <input type="file" name="file" required class="text-sm text-zinc-300 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-zinc-800 file:text-zinc-50 hover:file:bg-zinc-700 transition-all cursor-pointer focus:outline-none w-full sm:w-auto">
                <button type="submit" class="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-zinc-300 bg-zinc-50 text-zinc-900 hover:bg-zinc-200 h-9 px-4 w-full sm:w-auto mt-2 sm:mt-0">Upload</button>
            </div>
            <p class="text-xs text-zinc-500 mt-3">Only one attachment allowed per note. Attachments are removed after 10 minutes.</p>
        </form>
        @endif
    </div>

    <div class="bg-[#121212] border border-zinc-800 rounded-xl p-6 md:p-8 shadow-sm">
        <h2 class="text-xl font-semibold tracking-tight mb-2 text-zinc-50">Send to Admin</h2>
        <p class="text-zinc-400 text-sm mb-4">Request an administrator to review this note.</p>
        <form id="reportForm" action="{{ route('notes.report', $note) }}" method="POST">
            @csrf
            <button
                id="reportSubmitButton"
                type="submit"
                class="inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-yellow-500 bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20 border border-yellow-500/20 h-9 px-4 py-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
                <span
                    id="reportSpinner"
                    class="hidden h-4 w-4 animate-spin rounded-full border-2 border-yellow-500/30 border-t-yellow-500"
                    aria-hidden="true"
                ></span>
                <span id="reportButtonText">Send for Review</span>
            </button>
        </form>
        @if(session('reported'))
        <div class="mt-4 p-3 bg-green-500/10 border border-green-500/20 rounded-md text-green-400 text-sm font-medium">
            {{ session('reported') }}
        </div>
        @endif
        @error('report')
        <div class="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-md text-red-400 text-sm font-medium">
            {{ $message }}
        </div>
        @enderror
    </div>

    <div class="pt-2">
        <a href="{{ route('notes.index') }}" class="inline-flex items-center text-sm font-medium text-zinc-400 hover:text-zinc-50 transition-colors">
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back to Notes
        </a>
    </div>
</div>
@endsection

@push('scripts')
<script @cspnonce>
document.getElementById('deleteNoteForm').addEventListener('submit', function (e) {
    if (!confirm('Are you sure you want to delete this note?')) {
        e.preventDefault();
    }
});

document.getElementById('reportForm').addEventListener('submit', function () {
    const submitButton = document.getElementById('reportSubmitButton');
    const spinner = document.getElementById('reportSpinner');
    const buttonText = document.getElementById('reportButtonText');

    submitButton.disabled = true;
    spinner.classList.remove('hidden');
    buttonText.textContent = 'Sending...';
});
</script>
@endpush
