const { chromium } = require('playwright');

const APPURL = process.env.APPURL || 'http://app:8080';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@example.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'password';
const EXECUTABLE_PATH = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || process.env.CHROME_BIN;
const LOGIN_URL = `${APPURL}/admin/login`;
const ADMIN_NOTES_URL = `${APPURL}/admin/notes`;
const STARTUP_RETRIES = Number(process.env.BOT_STARTUP_RETRIES || 3);
const NAVIGATION_TIMEOUT = Number(process.env.BOT_NAVIGATION_TIMEOUT || 30000);
const APP_HOSTNAME = new URL(APPURL).hostname;
const LOG_EXTERNAL_REQUESTS = process.env.BOT_LOG_EXTERNAL_REQUESTS !== 'false';

let browser;

async function getBrowser() {
    if (browser?.isConnected()) {
        return browser;
    }

    browser = await chromium.launch({
        headless: true,
        executablePath: EXECUTABLE_PATH,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-gpu',
        ],
    });

    browser.on('disconnected', () => {
        browser = undefined;
    });

    return browser;
}

async function createVisitContext() {
    const activeBrowser = await getBrowser();

    const context = await activeBrowser.newContext({
        ignoreHTTPSErrors: true,
    });

    return context;
}

async function isLoggedOut(page) {
    if (page.url().includes('/admin/login')) {
        return true;
    }

    return page.locator('input[name="email"]').isVisible().catch(() => false);
}

function attachRequestLogging(page) {
    if (!LOG_EXTERNAL_REQUESTS) {
        return;
    }

    page.on('request', request => {
        const requestUrl = request.url();
        const hostname = new URL(requestUrl).hostname;

        if (hostname !== APP_HOSTNAME) {
            console.log(`[bot] external request -> ${request.resourceType()} ${requestUrl}`);
        }
    });

    page.on('requestfailed', request => {
        const requestUrl = request.url();
        const hostname = new URL(requestUrl).hostname;

        if (hostname !== APP_HOSTNAME) {
            const failure = request.failure();
            console.log(`[bot] external request failed -> ${request.resourceType()} ${requestUrl} (${failure?.errorText || 'unknown'})`);
        }
    });

    page.on('response', response => {
        const responseUrl = response.url();
        const hostname = new URL(responseUrl).hostname;

        if (hostname !== APP_HOSTNAME) {
            console.log(`[bot] external response <- ${response.status()} ${responseUrl}`);
        }
    });
}

async function loginInBrowser(page) {
    console.log(`[bot] logging in as ${ADMIN_EMAIL} in browser`);
    console.log(`[bot] navigating to ${LOGIN_URL}`);
    await page.goto(LOGIN_URL, { waitUntil: 'domcontentloaded', timeout: NAVIGATION_TIMEOUT });
    
    console.log(`[bot] filling login form`);
    await page.locator('input[name="email"]').fill(ADMIN_EMAIL);
    await page.locator('input[name="password"]').fill(ADMIN_PASSWORD);
    
    console.log(`[bot] clicking submit and waiting for navigation/URL change`);
    await Promise.all([
        page.waitForURL(currentUrl => !currentUrl.toString().includes('/admin/login'), {
            timeout: NAVIGATION_TIMEOUT,
        }).then(() => console.log(`[bot] URL changed to ${page.url()}`)),
        page.locator('button[type="submit"]').click(),
    ]);

    if (await isLoggedOut(page)) {
        console.error(`[bot] login failed, still at ${page.url()}`);
        throw new Error('Admin login did not produce a valid authenticated session');
    }

    console.log(`[bot] login successful, current URL: ${page.url()}`);
    if (!page.url().startsWith(ADMIN_NOTES_URL)) {
        console.log(`[bot] navigating to admin notes: ${ADMIN_NOTES_URL}`);
        await page.goto(ADMIN_NOTES_URL, { waitUntil: 'domcontentloaded', timeout: NAVIGATION_TIMEOUT });
    }
}

async function runVisit(url, forceRefresh = false) {
    let context;
    let page;

    try {
        console.log(`[bot] starting runVisit for ${url} (forceRefresh: ${forceRefresh})`);
        context = await createVisitContext();
        page = await context.newPage();
        page.setDefaultTimeout(NAVIGATION_TIMEOUT);
        page.setDefaultNavigationTimeout(NAVIGATION_TIMEOUT);
        attachRequestLogging(page);
        
        await loginInBrowser(page);
        
        console.log(`[bot] visiting target URL: ${url}`);
        const response = await page.goto(url, { waitUntil: 'commit', timeout: NAVIGATION_TIMEOUT });
        console.log(`[bot] navigation to ${url} finished with status ${response ? response.status() : 'unknown'}`);

        if (!forceRefresh && await isLoggedOut(page)) {
            console.log('[bot] login session not active during visit, retrying');
            await context.close().catch(() => {});

            return runVisit(url, true);
        }

        console.log(`[bot] waiting 5s for page to settle`);
        await page.waitForTimeout(5000);
        console.log(`[bot] visit to ${url} completed`);

        return true;
    } catch (e) {
        console.error(`[bot] ERROR during visit: ${e.stack}`);
        if (browser) {
            console.log(`[bot] closing browser due to error`);
            await browser.close().catch(() => {});
            browser = undefined;
        }

        return false;
    } finally {
        if (context) {
            await context.close().catch(() => {});
        }
    }
}

async function visit(url) {
    return runVisit(url);
}

const http = require('http');

http.createServer(async (req, res) => {
    if (req.method === 'POST' && req.url === '/visit') {
        let body = '';
        req.on('data', c => body += c);
        req.on('end', async () => {
            const { url } = Object.fromEntries(new URLSearchParams(body));
            if (!url) { res.writeHead(400); return res.end('missing url'); }

            const ok = await visit(url);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(ok ? { success: true } : { error: 'failed' }));
        });
    } else {
        res.writeHead(404);
        res.end('not found');
    }
}).listen(3000, () => console.log('[bot] listening on :3000'));
