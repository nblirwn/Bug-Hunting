#!/bin/bash
set -e

APP_KEY="base64:$(openssl rand -base64 32)"
DB_PASSWORD="$(openssl rand -hex 16)"
MYSQL_ROOT_PASSWORD="$(openssl rand -hex 16)"
ADMIN_PASSWORD="$(openssl rand -hex 12)"
TEST_USER_PASSWORD="$(openssl rand -hex 12)"
FLAG="NETICS{$(openssl rand -hex 16)}"
ADMIN_EMAIL="$(openssl rand -hex 8)@netics.its.ac.id"
TEST_USER_EMAIL="$(openssl rand -hex 8)@netics.its.ac.id"

sed -i "s|^APP_KEY=.*|APP_KEY=${APP_KEY}|" .env
sed -i "s|^DB_PASSWORD=.*|DB_PASSWORD=${DB_PASSWORD}|" .env
sed -i "s|^MYSQL_ROOT_PASSWORD=.*|MYSQL_ROOT_PASSWORD=${MYSQL_ROOT_PASSWORD}|" .env
sed -i "s|^ADMIN_PASSWORD=.*|ADMIN_PASSWORD=${ADMIN_PASSWORD}|" .env
sed -i "s|^TEST_USER_PASSWORD=.*|TEST_USER_PASSWORD=${TEST_USER_PASSWORD}|" .env
sed -i "s|^FLAG=.*|FLAG=${FLAG}|" .env
sed -i "s|^ADMIN_EMAIL=.*|ADMIN_EMAIL=${ADMIN_EMAIL}|" .env
sed -i "s|^TEST_USER_EMAIL=.*|TEST_USER_EMAIL=${TEST_USER_EMAIL}|" .env

docker compose up --build -d
