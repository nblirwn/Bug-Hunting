from flask import Flask, render_template, request, make_response, redirect, url_for

app = Flask(__name__)

FLAG = "KICAU{NABILIRAWAN_NABILIRAWAN_NABILIRAWAN_NABILIRAWAN_NABILIRAWAN}"


@app.route("/")
def index():
    # Set default cookie 
    resp = make_response(render_template("index.html"))
    if not request.cookies.get("role"):
        resp.set_cookie("role", "guest")
    return resp


@app.route("/robots.txt")
def robots():
    # Hint: arahkan ke /admin
    content = "User-agent: *\nDisallow: /admin\n"
    return content, 200, {"Content-Type": "text/plain"}


@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username", "guest")
    resp = make_response(redirect(url_for("dashboard")))
    resp.set_cookie("role", "guest")
    resp.set_cookie("username", username)
    return resp


@app.route("/dashboard")
def dashboard():
    username = request.cookies.get("username", "Anonim")
    return render_template("dashboard.html", username=username)


@app.route("/admin")
def admin():
    role = request.cookies.get("role", "guest")
    if role == "admin":
        return render_template("admin.html", flag=FLAG)
    else:
        return render_template("forbidden.html", role=role), 403


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
