<ul style="list-style: none; padding: 0; list-style-type: none;">
	<li style="padding-bottom: 10px; font-size:14px; margin-left: 15px;">
		<strong><?php echo wp_kses_post( 'Sample label' ); ?>:</strong>
		<div class="text" style="padding-left: 20px;">
			<?php echo wp_kses_post( 'Sample value' ); ?>
		</div>
	</li>
</ul>
