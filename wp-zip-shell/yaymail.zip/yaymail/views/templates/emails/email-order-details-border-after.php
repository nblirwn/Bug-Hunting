<?php

defined( 'ABSPATH' ) || exit;
$sent_to_admin = ( isset( $sent_to_admin ) ? true : false );
$email         = ( isset( $email ) ? $email : '' );
$plain_text    = ( isset( $plain_text ) ? $plain_text : '' );

